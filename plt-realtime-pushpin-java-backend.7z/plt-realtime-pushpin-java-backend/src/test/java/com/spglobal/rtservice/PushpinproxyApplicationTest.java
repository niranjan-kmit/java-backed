package com.spglobal.rtservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PushpinproxyApplicationTest {

	@Test
	void contextLoads() {
	}
}
